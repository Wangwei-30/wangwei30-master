package com.ww30app.wangwei30;

import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseActivity extends AppCompatActivity {

    void initView(){};

    void initData(){};

}
